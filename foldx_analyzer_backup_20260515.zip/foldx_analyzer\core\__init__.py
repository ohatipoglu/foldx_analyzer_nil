"""Core analysis modules for FoldX Analyzer."""
