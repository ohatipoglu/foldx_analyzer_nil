#!/usr/bin/env python3
"""
FoldX Genetic Analyzer & Visualizer

Main application entry point.

This application automates the analysis of FoldX PSSM output files,
calculating ΔΔG values, identifying ideal mutation candidates, and
generating publication-quality visualizations.

Usage:
    python -m foldx_analyzer.main
    
Or run directly:
    python main.py
"""

import sys
import os

# Add parent directory to path for package imports
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

import customtkinter as ctk

from foldx_analyzer.ui.main_window import MainWindow
from foldx_analyzer.utils.logger import get_logger


def main():
    """Main entry point for the application."""
    logger = get_logger()
    
    # Configure global settings
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
    
    # Create and run application
    try:
        app = MainWindow()
        logger.info("Application started successfully")
        app.mainloop()
        
    except KeyboardInterrupt:
        logger.info("Application terminated by user")
        sys.exit(0)
        
    except Exception as e:
        logger.critical(f"Fatal error: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
