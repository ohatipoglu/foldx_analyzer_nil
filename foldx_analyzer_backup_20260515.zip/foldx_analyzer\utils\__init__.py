"""Utility modules for FoldX Analyzer."""
