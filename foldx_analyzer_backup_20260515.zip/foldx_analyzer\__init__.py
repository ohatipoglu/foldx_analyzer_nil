"""
FoldX Genetic Analyzer & Visualizer

A comprehensive tool for automated analysis of FoldX PSSM output files.
"""

__version__ = "2.0.0"
__author__ = "FoldX Project Team"
